package Project;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Contact_admin {
    public static void main(String[] args) throws InterruptedException {
        // Set up Firefox driver
        WebDriverManager.firefoxdriver().setup();
        // Create a new instance of the Firefox driver
        WebDriver driver = new FirefoxDriver();
        // Create the Wait object
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        // Open the page
        driver.get("https://alchemy.hguy.co/lms/");
        Thread.sleep(1000);
        driver.findElement(By.xpath("/html/body/div/header/div/div/div/div/div[3]/div/nav/div/ul/li[4]/a")).click();
        Thread.sleep(10000);
        driver.findElement(By.id("wpforms-8-field_0")).sendKeys("ABCD");
        driver.findElement(By.id("wpforms-8-field_1")).sendKeys("ABCD@gmail.com");
        driver.findElement(By.id("wpforms-8-field_3")).sendKeys("abcd_subject");
        driver.findElement(By.id("wpforms-8-field_2")).sendKeys("Abcd_message");
        driver.findElement(By.id("wpforms-submit-8")).click();
        String Actual_confirmation = driver.findElement(By.id("wpforms-confirmation-8")).getText();
        String expected_confirmation = "Thanks for contacting us! We will be in touch with you shortly.";

        if (Actual_confirmation.equals(expected_confirmation)) {
            driver.close();
        }
    }
}
